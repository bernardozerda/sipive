﻿Public Class frmCliente

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim servicio As New WebService.SDHT
        Dim validacion As New WebService.cadena
        Dim consulta As New WebService.boleano
        Dim numero As Integer

        Try
            validacion = servicio.validarUsuario("sdhtusuario", "Ochochar*1")
            If (validacion.error.Equals("")) Then
                Try
                    numero = Integer.Parse(txtDocumento.Text)
                    consulta = servicio.ciudadanoRegistrado(numero, validacion.texto)
                    If (consulta.estado.Equals(True)) Then
                        lblRespuesta.ForeColor = Color.Blue
                        lblRespuesta.Text = "El documento " & numero & " está registrado en la base de datos"
                    Else
                        lblRespuesta.ForeColor = Color.Red
                        lblRespuesta.Text = "El documento " & numero & " es deconocido en la base de datos"
                    End If
                Catch ex As Exception
                    lblRespuesta.ForeColor = Color.Red
                    lblRespuesta.Text = "No es un número válido"
                End Try
            Else
                lblRespuesta.Text = validacion.error
            End If
        Catch ex As Exception
            lblRespuesta.Text = ex.Message
        End Try
    End Sub
End Class
