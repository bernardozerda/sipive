<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es-es" lang="es-es" >
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="title" content="Cliente Web Service SDHT-SDVE">
      <meta name="keywords" content="sdht,webservice,sdve" />
      <meta name="description" content="Cliente Web Service SDVE">
      <meta http-equiv="Content-Language" content="es">
      <meta name="robots" content="index,  nofollow" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <title>Cliente WS SDVE</title>
      
      <script type="text/javascript">
         
         function verDetalle(){
            document.getElementById("detalle").hidden = false;
         }
         
      </script>
      
   </head>
   <body> 

      <?php

         /**
          * LIBRERIA PARA LA CONEXION AL SERVICIO WEB
          */

         include( "./nusoap/nusoap.php" );

         // cuando se hace submit al formulario entra
         if( ! empty( $_POST ) ){

            /**
             * CONFIGURACION DE LOS DATOS DE LA CUENTA
             */

            //$servidor = "localhost";
            //$servidor = "192.168.6.41:8081";
            $servidor = "www.habitatbogota.gov.co";
            $usuario  = "sdhtusuario"; // esta cuenta no existe
            $clave    = "Ochochar*1";
            
            /**
             * CONEXION AL WEB SERVICE
             */

            $cliente = new nusoap_client( "http://" . $servidor . "/sdv/webservice/index.php?wsdl" , true );

            /**
             * CONSUMO DE SERVICIOS
             */

            // para metros para la validacion del usuario
            $parametros = array();
            $parametros['usuario'] = $usuario;
            $parametros['clave']   = $clave;
            
            // llamado al servicio de autenticacion
            $resultadoValidacion = $cliente->call( 'validarUsuario' , $parametros );
            
            // valida si hay errores en la autenticacion
            if( $resultadoValidacion['return']['error'] == "" ){

               // Valida que haya un dato valido digitado
               if( intval( $_POST['documento'] ) != 0 ){

                  // parametros para la consulta de documentos
                  $parametros = array();
                  $parametros['documento']     = $_POST['documento'];                        // Numero de dcumento digitado
                  $parametros['identificador'] = $resultadoValidacion['return']['texto'];    // Token de sesion enviado por el metodo de validacion

                  // llamado al servicio de consulta
                  $resultadoConsulta = $cliente->call( 'ciudadanoRegistrado' , $parametros );

                  // valida si hay errores
                  if( $resultadoConsulta['return']['error'] == "" ){
                     echo "<center>";
                     echo "<h2>Resultado</h2>";
                     echo "<span style='color:blue;'><h4>El ciduadano identificado con el documento de identidad ". number_format( $_POST['documento'] ) . " ";
                     echo ( $resultadoConsulta['return']['estado'] == "true" )? "<span style='color:green'>est&aacute;</span>" : "<span style='color:red'>no est&aacute;</span>";
                     echo " registrado en nuestra base de datos</h4></span>";
                     echo "</center>";
                  } else {
                     echo "<center>";
                     echo "<span style='color:red'><h2>" . utf8_encode( $resultadoConsulta['return']['error'] ) . "</h2></span>";
                     echo "</center>";
                  }
               } else {
                  echo "<center>";
                  echo "<span style='color:red'><h2>No es un dato de consulta v&aacute;lido</h2></span>";
                  echo "</center>";
               }
            } else{
               echo "<center>";
               echo "<span style='color:red'><h2>" . utf8_encode( $resultadoValidacion['return']['error'] ) . "</h2></span>";
               echo "</center>";
            }

            echo "<center>";
            echo "<a href='#' onClick='verDetalle();'>Ver detalles de las respuestas</a>";
            echo "</center><br>";
            echo "<div id='detalle' hidden='true' style='background-color:#e4e4e4; padding:10px;'>";
               echo "<b>Detalle de la respuesta del llamado al servicio de validaci&oacute;n</b>";
                  echo "<pre>";
                     var_dump( $resultadoValidacion );
                  echo "</pre>";
               echo "<b>Detalle de la respuesta del llamado al servicio de consulta</b>";
                  echo "<pre>";
                     var_dump( $resultadoConsulta );
                  echo "</pre>";
            echo "</div>";

         }

      ?>

      <!-- FORMULARIO PARA REALIZAR LA CONSULTA -->
      <center>
         <form name="formulario" action="./index.php" method="post">
            <table>
               <tr>
                  <td><h2>Cliente de prueba de web service para SDVE</h2></td>
               </tr>
               <tr>
                  <td>
                     <label for="documento">N&uacute;mero de documento</label>
                     <input type="text" name="documento" required pattern="[0-9]+" value="<?php echo $_POST['documento'] ?>">
                     <button type="submit">
                        Enviar consulta
                     </button>
                  </td>
               </tr>
            </table>
         </form>
      </center>
   
   </body>
</html>
