package co.gov.habitatbogota.www.soap.SDHT;

public class SDHTPortTypeProxy implements co.gov.habitatbogota.www.soap.SDHT.SDHTPortType {
  private String _endpoint = null;
  private co.gov.habitatbogota.www.soap.SDHT.SDHTPortType sDHTPortType = null;
  
  public SDHTPortTypeProxy() {
    _initSDHTPortTypeProxy();
  }
  
  public SDHTPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initSDHTPortTypeProxy();
  }
  
  private void _initSDHTPortTypeProxy() {
    try {
      sDHTPortType = (new co.gov.habitatbogota.www.soap.SDHT.SDHTLocator()).getSDHTPort();
      if (sDHTPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sDHTPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sDHTPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sDHTPortType != null)
      ((javax.xml.rpc.Stub)sDHTPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public co.gov.habitatbogota.www.soap.SDHT.SDHTPortType getSDHTPortType() {
    if (sDHTPortType == null)
      _initSDHTPortTypeProxy();
    return sDHTPortType;
  }
  
  public co.gov.habitatbogota.www.soap.SDHT.ValidarUsuarioResponseType validarUsuario(co.gov.habitatbogota.www.soap.SDHT.ValidarUsuarioRequestType parameters) throws java.rmi.RemoteException{
    if (sDHTPortType == null)
      _initSDHTPortTypeProxy();
    return sDHTPortType.validarUsuario(parameters);
  }
  
  public co.gov.habitatbogota.www.soap.SDHT.CiudadanoRegistradoResponseType ciudadanoRegistrado(co.gov.habitatbogota.www.soap.SDHT.CiudadanoRegistradoRequestType parameters) throws java.rmi.RemoteException{
    if (sDHTPortType == null)
      _initSDHTPortTypeProxy();
    return sDHTPortType.ciudadanoRegistrado(parameters);
  }
  
  
}