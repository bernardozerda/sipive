/**
 * SDHTLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package co.gov.habitatbogota.www.soap.SDHT;

public class SDHTLocator extends org.apache.axis.client.Service implements co.gov.habitatbogota.www.soap.SDHT.SDHT {

    public SDHTLocator() {
    }


    public SDHTLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public SDHTLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for SDHTPort
    private java.lang.String SDHTPort_address = "http://www.habitatbogota.gov.co/sdv/webservice/index.php";

    public java.lang.String getSDHTPortAddress() {
        return SDHTPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String SDHTPortWSDDServiceName = "SDHTPort";

    public java.lang.String getSDHTPortWSDDServiceName() {
        return SDHTPortWSDDServiceName;
    }

    public void setSDHTPortWSDDServiceName(java.lang.String name) {
        SDHTPortWSDDServiceName = name;
    }

    public co.gov.habitatbogota.www.soap.SDHT.SDHTPortType getSDHTPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(SDHTPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getSDHTPort(endpoint);
    }

    public co.gov.habitatbogota.www.soap.SDHT.SDHTPortType getSDHTPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            co.gov.habitatbogota.www.soap.SDHT.SDHTBindingStub _stub = new co.gov.habitatbogota.www.soap.SDHT.SDHTBindingStub(portAddress, this);
            _stub.setPortName(getSDHTPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setSDHTPortEndpointAddress(java.lang.String address) {
        SDHTPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (co.gov.habitatbogota.www.soap.SDHT.SDHTPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                co.gov.habitatbogota.www.soap.SDHT.SDHTBindingStub _stub = new co.gov.habitatbogota.www.soap.SDHT.SDHTBindingStub(new java.net.URL(SDHTPort_address), this);
                _stub.setPortName(getSDHTPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("SDHTPort".equals(inputPortName)) {
            return getSDHTPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.habitatbogota.gov.co/soap/SDHT", "SDHT");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.habitatbogota.gov.co/soap/SDHT", "SDHTPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("SDHTPort".equals(portName)) {
            setSDHTPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
