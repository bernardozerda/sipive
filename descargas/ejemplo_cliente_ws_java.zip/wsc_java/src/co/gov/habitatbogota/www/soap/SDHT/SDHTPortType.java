/**
 * SDHTPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package co.gov.habitatbogota.www.soap.SDHT;

public interface SDHTPortType extends java.rmi.Remote {

    /**
     * Verifica la autenticidad del usuario
     */
    public co.gov.habitatbogota.www.soap.SDHT.ValidarUsuarioResponseType validarUsuario(co.gov.habitatbogota.www.soap.SDHT.ValidarUsuarioRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Verifica si un numero de documento existe en la base de datos
     * SDVE
     */
    public co.gov.habitatbogota.www.soap.SDHT.CiudadanoRegistradoResponseType ciudadanoRegistrado(co.gov.habitatbogota.www.soap.SDHT.CiudadanoRegistradoRequestType parameters) throws java.rmi.RemoteException;
}
