package Cliente;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.awt.Panel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import co.gov.habitatbogota.www.soap.SDHT.*;

public class Cliente {

	private JFrame frmSdhtSdve;
	private JTextField textField;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {			
			public void run() {
				try {
					Cliente window = new Cliente();
					window.frmSdhtSdve.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Cliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSdhtSdve = new JFrame();
		frmSdhtSdve.setTitle("SDHT - SDVE");
		frmSdhtSdve.setBounds(100, 100, 583, 309);
		frmSdhtSdve.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSdhtSdve.getContentPane().setLayout(null);
		
		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 575, 107);
		frmSdhtSdve.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblEscudo = new JLabel("");
		//lblEscudo.setIcon(new ImageIcon("D:\\Mis im\u00E1genes\\escudo.jpg"));
		lblEscudo.setIcon(new ImageIcon( Cliente.class.getResource("/Cliente/escudo.jpg") ));
		lblEscudo.setBounds(12, 0, 99, 107);
		panel.add(lblEscudo);
		
		JLabel lblTitulo = new JLabel("Secretar\u00EDa Distrital de H\u00E1bitat");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Dialog", Font.BOLD, 28));
		lblTitulo.setBounds(111, 12, 452, 37);
		panel.add(lblTitulo);
		
		JLabel lblSubtitulo = new JLabel("Ejemplo de Consumo de Servicios Web para SDVE");
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblSubtitulo.setBounds(111, 61, 452, 16);
		panel.add(lblSubtitulo);
		
		Panel panel_1 = new Panel();
		panel_1.setBounds(0, 113, 575, 44);
		frmSdhtSdve.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNmero = new JLabel("N\u00FAmero de Identificaci\u00F3n");
		lblNmero.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNmero.setBounds(12, 12, 188, 16);
		panel_1.add(lblNmero);
		
		textField = new JTextField();
		textField.setFont(new Font("Dialog", Font.PLAIN, 14));
		textField.setBounds(196, 11, 257, 24);
		panel_1.add(textField);
		textField.setColumns(10);
		
		Panel panel_2 = new Panel();
		panel_2.setBounds(0, 163, 575, 54);
		frmSdhtSdve.getContentPane().add(panel_2);
		
		final JLabel lblRespuesta = new JLabel("");
		
		lblRespuesta.setFont(new Font("Dialog", Font.PLAIN, 16));
		panel_2.add(lblRespuesta);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int numero = Integer.parseInt( textField.getText() );
					
					co.gov.habitatbogota.www.soap.SDHT.SDHTPortTypeProxy port = new co.gov.habitatbogota.www.soap.SDHT.SDHTPortTypeProxy();
					
					ValidarUsuarioRequestType parAutenticacion = new ValidarUsuarioRequestType();
					parAutenticacion.setUsuario("prueba");
					parAutenticacion.setClave("prueba");
					
					ValidarUsuarioResponseType retAutenticacion = port.validarUsuario(parAutenticacion);
					Cadena resAutenticacion = retAutenticacion.get_return();
					if( "".equals(resAutenticacion.getError()) ){
						
						String identificador = resAutenticacion.getTexto();
						
						CiudadanoRegistradoRequestType parConsulta = new CiudadanoRegistradoRequestType();
						parConsulta.setDocumento(numero);
						parConsulta.setIdentificador(identificador);
						
						CiudadanoRegistradoResponseType retConsulta = port.ciudadanoRegistrado(parConsulta);
						Boleano resConsulta = retConsulta.get_return();
						if( "".equals(resConsulta.getError()) ){
							
							if( resConsulta.isEstado() ){
								lblRespuesta.setForeground(Color.BLUE);
								lblRespuesta.setText("El documento " + numero + " est� registrado");
							}else{
								lblRespuesta.setForeground(Color.RED);
								lblRespuesta.setText("El documento " + numero + " es desconocido");
							}
							
						}else{
							lblRespuesta.setForeground(Color.RED);
							lblRespuesta.setText(resConsulta.getError());
						}
						
						
					} else {
						lblRespuesta.setForeground(Color.RED);
						lblRespuesta.setText( resAutenticacion.getError() );
					}
					
					
					
				} catch ( Exception error ){
					lblRespuesta.setForeground(Color.RED);
					lblRespuesta.setText( "No es un numero v�lido" );
				}
			}

		});
		btnConsultar.setBounds(465, 9, 98, 26);
		panel_1.add(btnConsultar);
		
	}
	
}
